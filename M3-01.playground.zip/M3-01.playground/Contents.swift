import UIKit

func suma(num1: Float, num2: Float) -> Float {
    let resultado = num1 + num2
    return resultado
}

func resta(num1: Float, num2: Float) -> Float {
    let resultado = num1 - num2
    return resultado
}

func multiplicacion(num1: Float, num2: Float) -> Float {
    let resultado = num1 * num2
    return resultado
}

func division(num1: Float, num2: Float) -> Float? {
    if num2 == 0 {
        return nil
    }
    else {
        let resultado = num1 / num2
        return resultado
    }
}

print("En caso de la division, operador1 es el divisor y operador 2 es el dividendo")
func calculadora(operacion: String, operador1: Float, operador2: Float) {
    
    switch operacion {
        
    case "Suma":
        print("El resultado es: \(suma(num1:operador1, num2:operador2))")
    
    case "Resta":
        print("El resultado es: \(resta(num1:operador1, num2:operador2))")
        
    case "Multiplicacion":
        print("El resultado es: \(multiplicacion(num1:operador1, num2:operador2))")
        
    case "Division":
        if let resultado = division(num1:operador1, num2:operador2) {
            print("El resultado es \(resultado)")
        } else {
            print("NaN")
        }
        
    default:
        print("La opción seleccionada no es válida.")
    }
}

calculadora(operacion:"Division", operador1:3, operador2:0)
calculadora(operacion:"Division", operador1:3, operador2:45)
calculadora(operacion:"Multiplicacion", operador1:3, operador2:4)
calculadora(operacion:"Suma", operador1:3, operador2:45)
calculadora(operacion:"Resta", operador1:3, operador2:45)
